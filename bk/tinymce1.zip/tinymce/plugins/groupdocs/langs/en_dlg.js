tinyMCE.addI18n('en.groupdocs_dlg',{
	title : 'This is just a example title'
});
